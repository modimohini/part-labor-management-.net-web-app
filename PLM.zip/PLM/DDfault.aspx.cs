﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Configuration;


namespace PLM
{
    public partial class DDfault : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DropDownList1.DataSource =GetDataItem();
                DropDownList1.DataValueField = "PartId";
                DropDownList1.DataTextField = "TechName";
                DropDownList1.DataBind();


            }

        }

        protected void DropDownList1_SelectedIndexChange(object sender, EventArgs e)
        {

        }
    }
}